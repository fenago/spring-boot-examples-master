insert into course(id, username,description)
values(10001, 'fenago', 'Learn JPA');

insert into course(id, username,description)
values(10002, 'fenago', 'Learn Data JPA');

insert into course(id, username,description)
values(10003, 'fenago', 'Learn Microservices');