package com.in28minutes.fullstack.springboot.rest.api.springbootcorscrossorigincsrf.course;

public record Course(Long id,
                     String username,
                     String description) {

}