package com.in28minutes.fullstack.springboot.helloworld.springboothelloworldwithrouting.helloworld;

public record HelloWorldBean(String message) {

}