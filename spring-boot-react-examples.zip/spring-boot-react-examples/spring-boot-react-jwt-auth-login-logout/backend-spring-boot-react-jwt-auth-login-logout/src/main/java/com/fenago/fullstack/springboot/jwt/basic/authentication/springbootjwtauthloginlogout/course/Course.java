package com.in28minutes.fullstack.springboot.jwt.basic.authentication.springbootjwtauthloginlogout.course;

public record Course(Long id,
                     String username,
                     String description) {

}